﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCD
{
    public class Geometry
    {
        public class Coordinates
        {
            public double x;
            public double y;
            public char name;
        }
        public class vector
        {
            public double length;
            public char a;
            public char b;

            public static Geometry.vector Slength(Geometry.Coordinates A, Geometry.Coordinates B)
            {
                Geometry.vector vector = new Geometry.vector();
                vector.length = Math.Abs(Math.Sqrt(Math.Pow(A.x, 2) + Math.Pow(B.x, 2)));
                vector.a = A.name;
                vector.b = B.name;
                return vector;
            }
        }

        public class triangle
        {
            public double Pyrimeter;
            public string name;
            public static triangle SPyrimeter(Geometry.vector A, Geometry.vector B, Geometry.vector C, bool indicators)
            {
                Geometry.triangle triangle = new Geometry.triangle();
                triangle.Pyrimeter = A.length + B.length + C.length;
                triangle.name = Char.ToString(A.a) + Char.ToString(B.a) + Char.ToString(B.b);
                if (indicators) Console.WriteLine(" triangle \n\t triangle.name = {0} \n\t triangle.Pyrimeter = {1}",
                 triangle.name, triangle.Pyrimeter);

                return triangle;
            }
            public static triangle comparison(triangle A, triangle B)
            {
                if (A.Pyrimeter > B.Pyrimeter)
                    return A;
                else
                    return B;

            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Geometry.Coordinates A = new Geometry.Coordinates { x = 0, y = 0, name = 'A' };
            Geometry.Coordinates B = new Geometry.Coordinates { x = 3, y = 2, name = 'B' };
            Geometry.Coordinates C = new Geometry.Coordinates { x = 7, y = 5, name = 'C' };
            Geometry.Coordinates D = new Geometry.Coordinates { x = 9, y = 2, name = 'D' };
            // bool triangle_indicators = true;
            bool triangle_indicators = false;
            Console.WriteLine("Самый большой треугольник, который можно составить из точек A, B, C, D: {0}" , 
            Geometry.triangle.comparison
            (
                Geometry.triangle.comparison
                (
                    Geometry.triangle.SPyrimeter // ABC triangle
                    (
                        Geometry.vector.Slength(A, B),
                        Geometry.vector.Slength(B, C),
                        Geometry.vector.Slength(C, A),
                        triangle_indicators
                    ),
                    Geometry.triangle.SPyrimeter //ABD triangle
                    (
                        Geometry.vector.Slength(A, B),
                        Geometry.vector.Slength(B, D),
                        Geometry.vector.Slength(D, A),
                        triangle_indicators
                    )
                ),

                Geometry.triangle.SPyrimeter //ACD triangle
                (
                    Geometry.vector.Slength(A, C),
                    Geometry.vector.Slength(C, D),
                    Geometry.vector.Slength(D, A),
                    triangle_indicators
                )
            ).name
            );
            Console.ReadKey();
        }
    }
}
