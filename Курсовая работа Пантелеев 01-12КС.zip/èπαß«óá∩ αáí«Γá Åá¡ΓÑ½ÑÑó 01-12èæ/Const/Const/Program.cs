﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Const
{//--------класс персона------------------
    class Person
    {
        protected string name;
        protected int age;
        public Person()
        {
            Console.WriteLine("Name?");
            this.name = Console.ReadLine();
            Console.WriteLine("Age?");
            this.age = Convert.ToInt32(Console.ReadLine());
        }
        public virtual string get()
        {
            return String.Format("Person : Name - {0}, Age - {1}", this.name, this.age);
        }
    }
    //--------класс студент-------------
    class student : Person
    {
        protected string groupe;
        protected string fakult;
        public student()
        {
            this.groupe = "zik81";
            this.fakult = "FIOT";
        }
        public override string get()
        {
            return String.Format("Student : Name - {0}, Age - {1} Fakult - {2}, Group - {3}", this.name, this.age, this.fakult, this.groupe);
        }
    }
    //----------класс лектор-------------------
    class music : Person
    {
        protected string kurs;
        public music()
        {
            this.kurs = "phisycs";
        }
        public override string get()
        {
            return String.Format("MUSIC : Name - {0}, Age - {1}, Kourse - {2}", this.name, this.age, this.kurs);
        }
    }
    //-----класс заведующий кафедрой--------------
    class GNTARA : music
    {
        protected string department;
        public GNTARA()
        {
            this.department = "TK";
        }
        public override string get()
        {
            return String.Format("GNTARA : Name - {0}, Age - {1}, Kourse - {2}, Department- {3}", this.name, this.age, this.kurs, this.department);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Student Info");
            Person B = new student();
            Console.WriteLine("Enter Lector Info");
            Person C = new music();
            Console.WriteLine("Enter Zav Info");
            Person D = new GNTARA();
            Console.WriteLine(B.get());
            Console.WriteLine(C.get());
            Console.WriteLine(D.get());
            Console.ReadKey();
        }
    }
}

