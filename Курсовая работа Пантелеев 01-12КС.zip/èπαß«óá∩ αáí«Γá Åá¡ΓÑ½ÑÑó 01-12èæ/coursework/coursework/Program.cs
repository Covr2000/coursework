﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace ConsoleApplication5
{
 class Obl
    {
        public Obl()
        {
            oName = "xz";
            Population = 12;
            Square = 5;
        }
        public Obl(string oName, int Population, float
       Square)
        {
            this.oName = oName;
            this.Population = Population;
            this.Square = Square;
        }
        protected string oName;
        protected int Population;
        protected float Square;
        public string retOname()
        {
            return oName;
        }
        public string retPop()
        {
            return Convert.ToString(Population);
        }
        public string retSq()
        {
            return string.Format("{0} кв.км", Square);
        }
        public string PrintAll()
        {
            return string.Format("Область: {0}\nПлоща:{1}\nНаселення: {2}", oName, retSq(), Population);
        }
    }
    class Region : Obl
    {
        public Region()
        {
            regName = "neva#no";
        }

        public Region(string oName, string regName, int
        Population, float Square)
        {
            this.oName = oName;
            this.Population = Population;
            this.Square = Square;
            this.regName = regName;
        }
    protected string regName;
    public string retRname()
    {
        return regName;
    }
    public string PrintAll()
    {
        return string.Format("Район: {0}\nОбласть:{1}\nПлощадь: {2}\nНаселение: {3}", regName, oName, retSq(),Population);
    }
}
class Poselok : Region
{
    public Poselok()
    {
        posName = "PosNeva#no";
    }
    public Poselok(string oName, string regName, string
   posName, int Population, float Square)
    {
        this.oName = oName;
        this.Population = Population;
        this.Square = Square;
        this.regName = regName;
        this.posName = posName;
    }
    protected string posName;
    public string retPosName()
    {
        return posName;
    }
    public string PrintAll()
    {
        return string.Format("Село: {0} \nРайон:{1}\nОбласть: {2} \nПлощадь: {3} \nНаселение: {4}", posName,regName, oName, retSq(), Population);
    }
 }
class City : Region
{
    public City()
    {
        cName = "Cityname";
    }
    public City(string oName, string regName, string
   cName, int Population, float Square)
    {
        this.oName = oName;
        this.Population = Population;
        this.Square = Square;
        this.regName = regName;
        this.cName = cName;
    }
    protected string cName;
    public string retCname()
    {
        return cName;
    }
    public string PrintAll()
    {
        return string.Format("Город: {0}\nРайон:{1}\nОбласть: {2} \nПлощадь: {3} \nНаселение: {4}", cName,regName, oName, retSq(), Population);
    }
}
class Program
{
    static void Main(string[] args)
    {
        Obl Obl1 = new Obl("Житомирская", 54000, 32345);
        Region reg1 = new Region("Житомирская","Коростенский", 2000, 5235);
        Poselok pos1 = new Poselok("Житомирская","Коростенский", "Липники", 350, 235);
        City city1 = new City("Житомирская","Коростенский", "Лугини", 350, 235);
        Console.WriteLine(Obl1.PrintAll());
        Console.WriteLine("---------------");
        Console.WriteLine(reg1.PrintAll());
        Console.WriteLine("---------------");
        Console.WriteLine(pos1.PrintAll());
        Console.WriteLine("---------------");
        Console.WriteLine(city1.PrintAll());
        Console.ReadKey();
    }
}
}